// app/mine/page.tsx
import React from "react";
import {columns,MyBet} from "./columns"
import { DataTable } from "./data-table";

async function getData(): Promise<MyBet[]> {
    // Fetch data from your API here.
    return [
        {
            id: "728ed52f",
            bet: "Who will win the World Series?",
            value: 100,
            minParticipants: 10,
            status: "ended",
            yes: 10,
            no: 10,
            judge: "xx AI",
            endsAt: 1715702400,
        },
        {
            id: "728ed52g",
            bet: "Who will win the NBA Championship?",
            value: 150,
            status: "ongoing",
            minParticipants: 10,
            yes: 10,
            no: 10,
            judge: "xx AI",
            endsAt: 1715702400,
        },
        {
            id: "728ed52h",
            bet: "Who will win the Stanley Cup?",
            value: 120,
            status: "ended",
            minParticipants: 10,
            yes: 10,
            no: 10,
            judge: "xx AI",
            endsAt: 1715702400,
        },
        {
            id: "728ed52i",
            bet: "Who will win the World Cup?",
            value: 200,
            status: "ongoing",
            minParticipants: 10,
            yes: 10,
            no: 10,
            judge: "xx AI",
            endsAt: 1715702400,
        },
    ]
}


const Mine = async () => {
    // 示例数据
    const data = await getData()

    return (
        <div>
            <DataTable columns={columns} data={data}/>
        </div>
    );
};

export default Mine;
