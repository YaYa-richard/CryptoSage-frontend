// app/mine/layout.tsx
import React from "react";

const MineLayout = ({ children }: { children: React.ReactNode }) => {
    return (
        <div style={{ fontFamily: 'Arial, sans-serif', padding: '20px' }}>
            <header>
                <h1>个人页面</h1>
            </header>

            <main>
                {/* 渲染子页面内容 */}
                {children}
            </main>

            <footer style={{ marginTop: '20px', textAlign: 'center' }}>
                <p>&copy; 2024 个人页面</p>
            </footer>
        </div>
    );
};

export default MineLayout;
