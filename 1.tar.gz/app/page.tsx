import HyperText from "@/components/ui/hyper-text";
import { columns, Bet } from "./columns";
import { DataTable } from "./data-table";
import { CreateDialog } from "./create-dialog";
import RetroGrid from "@/components/ui/retro-grid";

// import FlickeringGrid from "@/components/ui/flickering-grid";

async function getData(): Promise<Bet[]> {
  // Fetch data from your API here.
  return [
    {
      id: "728ed52f",
      bet: "Who will win the US election?",
      value: 100,
      minParticipants: 10,
      status: "ongoing",
      yes: 10,
      no: 10,
      judge: "xx AI",
      endsAt: 1715702400,
    },
    {
      id: "728ed52f",
      bet: "Who will win ETHGlobal Finalist?",
      value: 100,
      minParticipants: 10,
      status: "ended",
      yes: 10,
      no: 10,
      judge: "xx AI",
      endsAt: 1715702400,
    },
    {
      id: "728ed52f",
      bet: "Who will win the Super Bowl?",
      value: 100,
      minParticipants: 10,
      status: "ongoing",
      yes: 10,
      no: 10,
      judge: "xx AI",
      endsAt: 1715702400,
    },
    {
      id: "728ed52f",
      bet: "Who will win the World Series?",
      value: 100,
      minParticipants: 10,
      status: "ended",
      yes: 10,
      no: 10,
      judge: "xx AI",
      endsAt: 1715702400,
    },
    {
      id: "728ed52g",
      bet: "Who will win the NBA Championship?",
      value: 150,
      status: "ongoing",
      minParticipants: 10,
      yes: 10,
      no: 10,
      judge: "xx AI",
      endsAt: 1715702400,
    },
    {
      id: "728ed52h",
      bet: "Who will win the Stanley Cup?",
      value: 120,
      status: "ended",
      minParticipants: 10,
      yes: 10,
      no: 10,
      judge: "xx AI",
      endsAt: 1715702400,
    },
    {
      id: "728ed52i",
      bet: "Who will win the World Cup?",
      value: 200,
      status: "ongoing",
      minParticipants: 10,
      yes: 10,
      no: 10,
      judge: "xx AI",
      endsAt: 1715702400,
    },
    {
      id: "728ed52j",
      bet: "Who will win the Super Bowl?",
      value: 180,
      status: "ended",
      minParticipants: 10,
      yes: 10,
      no: 10,
      judge: "xx AI",
      endsAt: 1715702400,
    },
    {
      id: "728ed52k",
      bet: "Who will win the UEFA Champions League?",
      value: 250,
      status: "ongoing",
      minParticipants: 10,
      yes: 10,
      no: 10,
      judge: "xx AI",
      endsAt: 1715702400,
    },

  ]
}

export default async function Home() {
  const data = await getData()
  return (
    <>
      
      <div className="container mx-auto w-full ">

        <div className="justify-start items-center py-20 h-full w-full flex flex-col">
          <div className="flex flex-row gap-4 text-5xl">
            <HyperText
              className="font-bold"
              text="The" />
            <HyperText
              className="font-bold"
              text="Easiest" />
            <HyperText
              className="font-bold"
              text="Way" />
            <HyperText
              className="font-bold"
              text="To" />
            <HyperText
              className="font-bold"
              text="Create" />
            <HyperText
              className="font-bold"
              text="A" />
            <HyperText className="font-bold" text="Bet" ></HyperText>
          </div>
          <div className="w-full max-w-6xl mt-10">
            <div className="flex flex-row justify-between py-4">
              <div className="text-2xl font-bold">Trending Bets</div>
              <div>
                <CreateDialog />
              </div>
            </div>
            <DataTable columns={columns} data={data} />
          </div>
        </div>
        <RetroGrid className="absolute bottom-0 right-0 -z-10" />
        {/* <FlickeringGrid
          className="-z-10 absolute inset-0 size-full"
          squareSize={4}
          gridGap={6}
          color="#6B7280"
          maxOpacity={0.5}
          flickerChance={0.1}
        /> */}
      </div>
    </>

  );
}
