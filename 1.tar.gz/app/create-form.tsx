"use client"

import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"


import { Button } from "@/components/ui/button"
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { toast } from "@/hooks/use-toast"
import { Textarea } from "@/components/ui/textarea"
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select"
import {ethers} from "ethers";
import {useState} from "react";

const LAZY_BET_FACTORY_ABI=[
    {
        "inputs": [],
        "stateMutability": "nonpayable",
        "type": "constructor"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "owner",
                "type": "address"
            }
        ],
        "name": "OwnableInvalidOwner",
        "type": "error"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "account",
                "type": "address"
            }
        ],
        "name": "OwnableUnauthorizedAccount",
        "type": "error"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "betAddress",
                "type": "address"
            },
            {
                "indexed": true,
                "internalType": "address",
                "name": "initiator",
                "type": "address"
            }
        ],
        "name": "BetCreated",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "previousOwner",
                "type": "address"
            },
            {
                "indexed": true,
                "internalType": "address",
                "name": "newOwner",
                "type": "address"
            }
        ],
        "name": "OwnershipTransferred",
        "type": "event"
    },
    {
        "inputs": [],
        "name": "allBets",
        "outputs": [
            {
                "internalType": "address[]",
                "name": "",
                "type": "address[]"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "name": "bets",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "betsCount",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "_message",
                "type": "string"
            },
            {
                "internalType": "address",
                "name": "_token",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "_minValue",
                "type": "uint256"
            },
            {
                "internalType": "address",
                "name": "_judge",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "_endTime",
                "type": "uint256"
            }
        ],
        "name": "createBet",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "lazyBetBytecode",
        "outputs": [
            {
                "internalType": "bytes",
                "name": "",
                "type": "bytes"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "owner",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "renounceOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "bytes",
                "name": "_lazyBetBytecode",
                "type": "bytes"
            }
        ],
        "name": "setLazyBetBytecode",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "newOwner",
                "type": "address"
            }
        ],
        "name": "transferOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    }
]
const LAZY_BET_FACTORY_ADDRESS="0xB93138dA9c65e85d6d97c795029F1D269d512b65"
const contract = new ethers.Contract(LAZY_BET_FACTORY_ADDRESS, LAZY_BET_FACTORY_ABI);
const FormSchema = z.object({
    username: z.string().min(2, {
        message: "Username must be at least 2 characters.",
    }),
    bet: z.string().min(10, {
        message: "Bet must be at least 10 characters.",
    }),
    value: z.number(),
    minParticipants: z.number(),
    judge: z.string().min(1, {
        message: "Judge must be at least 1 character.",
    }),
    endTime: z.date(),
})

export function CreateForm() {
    const form = useForm<z.infer<typeof FormSchema>>({
        resolver: zodResolver(FormSchema),
        defaultValues: {
            username: "",
            bet: "",
            value: 0,
            minParticipants: 0,
            judge: "",
            endTime: new Date(),
        },
    })
    const [account, setAccount] = useState<string | null>(null);
    const [provider, setProvider] = useState<ethers.Provider | null>(null);
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = provider.getSigner();
    function onSubmit(data: z.infer<typeof FormSchema>) {


        console.log(data)
        const web3Provider = new ethers.providers.Web3Provider(window.ethereum);
        setProvider(web3Provider);
        window.ethereum.request({ method: 'eth_requestAccounts' })
            .then((accounts: any[]) => {
                // 获取第一个账户地址
                setAccount(accounts[0]);
            })
            .catch((error: any) => {
                console.error("User rejected the request or error occurred:", error);
            });

        toast({
            title: "You submitted the following values:",
            description: (
                <pre className="mt-2 w-[340px] rounded-md bg-slate-950 p-4">
                    <code className="text-white">{JSON.stringify(data, null, 2)}</code>
                </pre>
            ),
        })
    }

    return (
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className=" space-y-6">
                <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Initiator</FormLabel>
                            <FormControl>
                                <Input placeholder="0x123..." {...field} />
                            </FormControl>
                            <FormDescription>
                                This is your public display name.
                            </FormDescription>
                            <FormMessage />
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="bet"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Bet</FormLabel>
                            <FormControl>
                                <Textarea placeholder="The bet you want to make" {...field} />
                            </FormControl>
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="value"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Value</FormLabel>
                            <FormControl>
                                <div className="flex items-center gap-2">
                                    <Input placeholder="How much you oyt into the pool"
                                        onChange={(e) => {
                                            const value = e.target.value;
                                            if (/^\d*\.?\d*$/.test(value)) {
                                                field.onChange((value))
                                            }
                                        }}
                                        value={field.value}
                                    />
                                    <span>ETH</span>
                                </div>
                            </FormControl>
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="minParticipants"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Minimum Participants</FormLabel>
                            <FormControl>
                                <div className="flex items-center gap-2">
                                    <Input placeholder="10" {...field}
                                        onChange={(e) => {
                                            const value = e.target.value;
                                            if (/^\d*\.?\d*$/.test(value)) {
                                                field.onChange((value))
                                            }
                                        }}
                                        value={field.value}
                                    />
                                    <span>ETH</span>
                                </div>
                            </FormControl>
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="judge"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>Judge</FormLabel>
                            <FormControl>
                                <Select onValueChange={field.onChange}
                                    defaultValue={field.value}
                                >
                                    <SelectTrigger className="w-full">
                                        <SelectValue placeholder="Select Judge" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="xx">XX</SelectItem>
                                        <SelectItem value="yy">YY</SelectItem>
                                        <SelectItem value="zz">ZZ</SelectItem>
                                    </SelectContent>
                                </Select>
                            </FormControl>
                        </FormItem>
                    )}
                />
                <FormField
                    control={form.control}
                    name="endTime"
                    render={({ field }) => (
                        <FormItem>
                            <FormLabel>End Time</FormLabel>
                            <FormControl>
                                <Input type="datetime-local" {...field} value={field.value ? new Date(field.value).toISOString().split('T')[0] + 'T' + new Date(field.value).toISOString().split('T')[1].slice(0, -1) : ''} />
                            </FormControl>
                        </FormItem>
                    )}
                />
                <Button type="submit">Submit</Button>
            </form>
        </Form>
    )
}
